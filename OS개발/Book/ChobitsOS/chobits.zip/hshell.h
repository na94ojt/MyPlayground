#ifndef _HIDEKI_SHELL_HEADER_FILE
#define _HIDEKI_SHELL_HEADER_FILE


/**********************************************************************************************************
 *                                                INCLUDE FILES                                           *
 **********************************************************************************************************/
#include "chobits.h"
#include "fatfs.h"


#endif /* #ifndef _HIDEKI_SHELL_HEADER_FILE */