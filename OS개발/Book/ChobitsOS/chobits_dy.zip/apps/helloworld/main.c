#include "chobits_api.h"

/* 
 * codes by Yeori
 *
 * title : Hellow World!
 * e-mail : alphamcu@hanmail.net
 * www : www.zap.pe.kr (english : zap.pe.kr/eng)
 */

int main()
{
	API_PrintText("Welcome to Chobits Operating System WORLD, man~! ;) \r\n");

	return 0;
}